package com.binary.dao;

import java.sql.*;
import java.io.*;
import java.util.*;

public class AddBookDao {
	public int price[];
	 public String author[];
	 public String name[];
	 public int id[];
	public boolean addBook(String name,String author,int price) throws Exception
	{
		int id=0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Alig_123");
		PreparedStatement st=con.prepareStatement("insert into the_binary_brain.books(id,name,author,price) values(?,?,?,?)");
		Statement st2=con.createStatement();
		ResultSet rs=st2.executeQuery("select * from the_binary_brain.books order by(id)");
		while(rs.next())
		{
			id=rs.getInt(1);
		}
		st.setInt(1, (id+1));
		st.setString(2, name);
		st.setString(3, author);
		st.setInt(4, price); 
		
		if(st.executeUpdate()==1)
		{
			con.close();
			return true;
		}
		else 
		{
			con.close();
			return false;  
		}
	}
	public void getBooks()
	{
		try
		{
		int n=0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Alig_123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from the_binary_brain.books");
		while(rs.next())
		{
			n=rs.getRow();
		}
		price=new int[n];
		id=new int[n];
		name=new String[n];
		author=new String[n];
		rs=st.executeQuery("select * from the_binary_brain.books order by(id) desc");
		for(int i=0;i<price.length;i++)
		{
			rs.next();
			id[i]=rs.getInt(1);
			name[i]=rs.getString(2);
			author[i]=rs.getString(3);
			price[i]=rs.getInt(4);
		}
		con.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}
	public void deleteBooks(int[] id)
	{
		try
		{
		int n=0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Alig_123");
		for(int i=0;i<id.length;i++)
		{
		PreparedStatement st=con.prepareStatement("delete from the_binary_brain.books where id=?");
		st.setInt(1,id[i]);
		st.executeUpdate();
		}
		con.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}
	public void updateBooks(int[] id,String[] name,String[] author,int[] price)
	{
		try
		{
		int n=0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Alig_123");
		for(int i=0;i<id.length;i++)
		{
		PreparedStatement st=con.prepareStatement("update the_binary_brain.books set name=?,author=?,price=? where id=?");
		st.setString(1,name[i]);
		st.setString(2,author[i]);
		st.setInt(3,price[i]);
		st.setInt(4,id[i]);
		st.executeUpdate();
		}
		con.close();
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}
	public int[] getPrice() {
		return price;
	}
	public void setPrice(int[] price) {
		this.price = price;
	}
	public String[] getAuthor() {
		return author;
	}
	public void setAuthor(String[] author) {
		this.author = author;
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
/*	public static void main(String[] args) throws Exception
	{
		AddBookDao ref=new AddBookDao();
		ref.addBook("sxc","scxz",1324);
	}  */
}
