package com.binary.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginDao {

	public boolean login(String uname,String password) throws Exception
	{
		/*Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Alig_123");
		PreparedStatement ps=con.prepareStatement("select * from the_binary_brain.login where uname=? and password=?");
		ps.setString(1,uname);
		ps.setString(2,password);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			return true;
		}
		else
			return false; */
		return true;
	}
}
