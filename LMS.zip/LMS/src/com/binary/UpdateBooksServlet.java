package com.binary;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.binary.dao.AddBookDao;

@WebServlet("/UpdateBooks")
public class UpdateBooksServlet extends HttpServlet {
	AddBookDao abd=new AddBookDao();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int l=0;
		 Enumeration<String> a=request.getParameterNames();
		 while(a.hasMoreElements())
		 {
			 l++;
			 a.nextElement();
		 }
		 int id[]=new int[l];
		 String name[]=new String[l];
		 String author[]=new String[l];
		 int price[]=new int[l];
		 int j=0;
		 Enumeration<String> b=request.getParameterNames();
		 for(int i=0;b.hasMoreElements();i++)
		 {
			 id[i]=Integer.parseInt(request.getParameter(b.nextElement()));
			 name[i]=request.getParameter(b.nextElement()).toString();
			 author[i]=request.getParameter(b.nextElement()).toString();
			 price[i]=Integer.parseInt(request.getParameter(b.nextElement()));
		 }
		 abd.updateBooks(id, name, author, price);
		 response.sendRedirect("Welcome.jsp");
	}

}
