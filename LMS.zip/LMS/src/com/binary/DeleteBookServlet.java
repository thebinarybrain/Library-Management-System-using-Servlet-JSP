package com.binary;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.binary.dao.AddBookDao;

@WebServlet("/deletebooks")
public class DeleteBookServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int l=0;
		 Enumeration<String> a=request.getParameterNames();
		 while(a.hasMoreElements())
		 {
			 l++;
			 a.nextElement();
		 }
		 int ele[]=new int[l];
		 int j=0;
		 Enumeration<String> b=request.getParameterNames();
		 for(int i=0;b.hasMoreElements();i++)
		 {
			 ele[i]=Integer.parseInt(request.getParameter(b.nextElement()));
		 }
		 AddBookDao abd=new AddBookDao();
		 abd.deleteBooks(ele);
		 response.sendRedirect("Welcome.jsp");
	}

}
