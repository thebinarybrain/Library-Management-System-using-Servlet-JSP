package com.binary;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.binary.dao.AddBookDao;

@WebServlet("/addbook")
public class AddBookServlet extends HttpServlet {
	
AddBookDao abd=new AddBookDao();
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name").toString();
		String author=request.getParameter("author").toString();
		int price=Integer.parseInt(request.getParameter("price"));
		HttpSession session=request.getSession();
		try {
			if(abd.addBook(name, author, price))
			{
				session.setAttribute("AddBook","success");
				response.sendRedirect("Welcome.jsp");
			}
			else
			{
				session.setAttribute("AddBook","failure");
				response.sendRedirect("Welcome.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			response.sendRedirect("Error.jsp");
			e.getMessage();
		}
			
	}

}
